/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.a5starcompany.com.ng.tflite_flutter_plus;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.a5starcompany.com.ng.tflite_flutter_plus";
  public static final String BUILD_TYPE = "debug";
}
