/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.tfliteflutter.tflite_flutter_helper;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "com.tfliteflutter.tflite_flutter_helper";
  public static final String BUILD_TYPE = "debug";
}
