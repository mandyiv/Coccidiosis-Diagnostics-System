/**
 * Automatically generated file. DO NOT MODIFY
 */
package net.jonhanson.flutter_native_splash;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String LIBRARY_PACKAGE_NAME = "net.jonhanson.flutter_native_splash";
  public static final String BUILD_TYPE = "debug";
}
